## Start app

```
  npm install
```

```
npm start
```